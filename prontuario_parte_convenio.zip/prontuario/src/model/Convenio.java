package model;

public class Convenio {

    private int idconvenio;
    private String convenioNome;
    private String convenioTipo;
    private String convenioArea;
    private String coparticipacao; // S/N

    // Construtor Completo
    public Convenio(int idconvenio, String convenioNome, String convenioTipo, String convenioArea, String coparticipacao) {
        this.idconvenio = idconvenio;
        this.convenioNome = convenioNome;
        this.convenioTipo = convenioTipo;
        this.convenioArea = convenioArea;
        this.coparticipacao = coparticipacao;
    }

    // Construtor para Inserção (sem idconvenio, pois ele é SERIAL/Auto-incrementado)
    public Convenio(String convenioNome, String convenioTipo, String convenioArea, String coparticipacao) {
        this.convenioNome = convenioNome;
        this.convenioTipo = convenioTipo;
        this.convenioArea = convenioArea;
        this.coparticipacao = coparticipacao;
    }
    
    // Getters e Setters
    public int getIdconvenio() {
        return idconvenio;
    }

    public void setIdconvenio(int idconvenio) {
        this.idconvenio = idconvenio;
    }

    public String getConvenioNome() {
        return convenioNome;
    }

    public void setConvenioNome(String convenioNome) {
        this.convenioNome = convenioNome;
    }

    public String getConvenioTipo() {
        return convenioTipo;
    }

    public void setConvenioTipo(String convenioTipo) {
        this.convenioTipo = convenioTipo;
    }

    public String getConvenioArea() {
        return convenioArea;
    }

    public void setConvenioArea(String convenioArea) {
        this.convenioArea = convenioArea;
    }

    public String getCoparticipacao() {
        return coparticipacao;
    }

    public void setCoparticipacao(String coparticipacao) {
        this.coparticipacao = coparticipacao;
    }
}