package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConvenioDAO {

    public boolean cadastrar(Convenio convenio) {
        
        // SQL CORRIGIDO: Usa o nome EXATO da coluna: convenio_coparticipacao
        String sql = "INSERT INTO convenio (convenio_nome, convenio_tipo, convenio_area, convenio_coparticipacao) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Usa a chamada estática (Conexao.getConnection())
            conn = Conexao.getConnection(); 
            
            stmt = conn.prepareStatement(sql);
            
            stmt.setString(1, convenio.getConvenioNome());
            stmt.setString(2, convenio.getConvenioTipo());
            stmt.setString(3, convenio.getConvenioArea());
            stmt.setString(4, convenio.getCoparticipacao());
            
            stmt.execute();
            
            return true; // Sucesso
            
        } catch (SQLException e) {
            // Este log mostrará se houver qualquer outro erro de SQL
            System.err.println("Falha CRÍTICA na Inserção SQL. Erro: " + e.getMessage());
            return false; // Falha (mostra "Erro ao salvar")
            
        } finally {
            // Fecha os recursos
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                // Fechamento silencioso
            }
        }
    }
}