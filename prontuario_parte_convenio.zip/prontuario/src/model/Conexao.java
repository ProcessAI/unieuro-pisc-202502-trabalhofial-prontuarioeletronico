package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    
    // 🔑 CORREÇÃO CRÍTICA: O nome do banco de dados deve ser 'Prontuario' 
    // com P maiúsculo, para corresponder ao seu PostgreSQL.
    private static final String URL = "jdbc:postgresql://localhost:5432/Prontuario"; 
    
    private static final String USUARIO = "postgres";
    private static final String SENHA = "123456"; 

    // Já corrigimos para 'static' para resolver o erro de compilação
    public static Connection getConnection() { 
        try {
            Class.forName("org.postgresql.Driver"); 
            return DriverManager.getConnection(URL, USUARIO, SENHA);
            
        } catch (SQLException e) {
            // Se falhar agora, é porque o servidor PostgreSQL está desligado.
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw new RuntimeException("Erro ao conectar ao banco de dados", e);
        } catch (ClassNotFoundException e) {
            System.err.println("Driver do PostgreSQL não encontrado.");
            throw new RuntimeException("Driver do PostgreSQL não encontrado.", e);
        }
    }
}