package view;

import controller.ControllerConvenio;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class TelaConvenio extends JFrame {

    private JTextField campoNome;
    private JTextField campoTipo;
    private JTextField campoArea;
    private JTextField campoCoparticipacao;
    private JButton botaoSalvar;

    public TelaConvenio() {
        setTitle("Cadastro de Convênio");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        iniciarComponentes();
    }

    private void iniciarComponentes() {
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(5, 2, 10, 10));

        painel.add(new JLabel("Nome do Convênio:"));
        campoNome = new JTextField();
        painel.add(campoNome);

        painel.add(new JLabel("Tipo (1 letra):"));
        campoTipo = new JTextField();
        painel.add(campoTipo);

        painel.add(new JLabel("Área (1 letra):"));
        campoArea = new JTextField();
        painel.add(campoArea);

        painel.add(new JLabel("Coparticipação (S/N):"));
        campoCoparticipacao = new JTextField();
        painel.add(campoCoparticipacao);

        painel.add(new JLabel(""));
        botaoSalvar = new JButton("Salvar");
        painel.add(botaoSalvar);

        botaoSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fazerCadastro();
            }
        });

        add(painel);
    }

    private void fazerCadastro() {
        String nome = campoNome.getText();
        String tipo = campoTipo.getText();
        String area = campoArea.getText();
        String coparticipacao = campoCoparticipacao.getText();

        ControllerConvenio controller = new ControllerConvenio();
        boolean sucesso = controller.salvar(nome, tipo, area, coparticipacao);

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Convênio Salvo com Sucesso!");
            campoNome.setText("");
            campoTipo.setText("");
            campoArea.setText("");
            campoCoparticipacao.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaConvenio().setVisible(true);
        });
    }
}