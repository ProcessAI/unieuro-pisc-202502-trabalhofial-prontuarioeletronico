package controller;

import model.Convenio;
import model.ConvenioDAO; // 🔑 CORREÇÃO: Necessário para a classe ser reconhecida

public class ControllerConvenio {

    /**
     * Recebe os dados da View e chama a DAO para salvar no banco.
     */
    public boolean salvar(String nome, String tipo, String area, String coparticipacao) {
        
        // 1. Cria o objeto Convenio (usando o construtor de inserção)
        Convenio convenio = new Convenio(nome, tipo, area, coparticipacao);
        
        // 2. Instancia a DAO
        ConvenioDAO dao = new ConvenioDAO();
        
        // 3. Cadastra e retorna o resultado
        return dao.cadastrar(convenio);
    }
    
    // ... [Outros métodos do controller, se houver]
}